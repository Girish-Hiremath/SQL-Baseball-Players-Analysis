use baseball;
-- PART I: SCHOOL ANALYSIS
-- 1. View the schools and school details tables

select * from schools;
select * from school_details;

-- 2. In each decade, how many schools were there that produced players?

select round(yearid, -1)  as Decade, count(distinct sc.schoolid) as schoolID
from schools sc
group by Decade
order by Decade;

-- 3. What are the names of the top 5 schools that produced the most players?

select distinct sd.name_full, count(playerid) as players from schools sc 
left join school_details sd on
sd.schoolid=sc.schoolid
group by sd.schoolid
order by players desc
limit 5;


-- 4. For each decade, what were the names of the top 3 schools that produced the most players?

with ds as(select distinct round(sc.yearid, -1) as decade, sd.name_full, count(playerid) as players from schools sc 
left join school_details sd on
sd.schoolid=sc.schoolid
group by sd.schoolid, decade),

rn as (select decade, name_full, players,
 row_number() over (partition by  decade order by players desc) as row_numb
from ds)
select * from rn 
where row_numb <= 3
order by decade desc, row_numb;

-- PART II: SALARY ANALYSIS
-- 1. View the salaries table

select * from salaries;

-- 2. Return the top 20% of teams in terms of average annual spending

with ts as (select teamid, yearid, sum(salary) as total_spend 
from salaries
group by teamid, yearid
order by teamid, yearid),

sp as (select teamid, avg(total_spend) as avgspend,
ntile(5) over (order by avg(total_spend) desc) as  spend_pct
from ts
group by teamid)

select teamid, round(avgspend / 1000000, 1) as avg_spent_in_millions
from sp;


-- 3. For each team, show the cumulative sum of spending over the years

select * from salaries;
with ts as (select yearid, teamid, sum(salary) as csum from salaries
group by yearid, teamid
order by yearid, teamid desc)

select teamid, yearid,
round(sum(csum) over(partition by teamid order by yearid)/ 1000000, 1) as cummulative_sum_in_millions
from ts;

-- 4. Return the first year that each team's cumulative spending surpassed 1 billion

select * from salaries;
with ts as (select yearid, teamid, sum(salary) as csum from salaries
group by yearid, teamid
order by yearid, teamid desc),

cs as (select teamid, yearid,
sum(csum) over(partition by teamid order by yearid) as cummulative_sum
from ts),

rn as (select teamid, yearid, cummulative_sum,
row_number() over (partition by teamid order by cummulative_sum)as rn from cs
where cummulative_sum > 1000000000)

select  * from rn where rn =1;

-- PART III: PLAYER CAREER ANALYSIS
-- 1. View the players table and find the number of players in the table

select * from players;

select count(distinct playerid) as num_players from players;
-- 2. For each player, calculate their age at their first game, their last game, and their career length (all in years). Sort from longest career to shortest career.

select nameGiven, debut, finalgame, 
Cast(concat(birthyear,'-', birthmonth,'-', birthday) as DATE ) as Birthday,
	Timestampdiff(year, Cast(concat(birthyear,'-', birthmonth,'-', birthday) as DATE), debut) as starting_age,
    Timestampdiff(year, Cast(concat(birthyear,'-', birthmonth,'-', birthday) as DATE), finalgame) as Last_match,
    Timestampdiff(year,debut, finalgame) as career_length from players
    order by career_length desc;


-- 3. What team did each player play on for their starting and ending years?

select * from players;

select p.playerid, 
s.yearid as starting_year, s.teamid as starting_team, e.yearid as ending_year, e.teamid as ending_team from players p
inner join salaries s on 
p.playerid = s.playerid
and Year(p.debut)=s.yearid

inner join salaries e on 
p.playerid = e.playerid
and Year(p.finalgame)=e.yearid;

-- 4. How many players started and ended on the same team and also played for over a decade?
select * from players;

select p.playerid, 
s.yearid as starting_year, s.teamid as starting_team, e.yearid as ending_year, e.teamid as ending_team from players p
inner join salaries s on 
p.playerid = s.playerid
and Year(p.debut)=s.yearid

inner join salaries e on 
p.playerid = e.playerid
and Year(p.finalgame)=e.yearid

where s.teamid = e.teamid and e.yearid > 10;

-- PART IV: PLAYER COMPARISON ANALYSIS
-- 1. View the players table

select * from players;

-- 2. Which players have the same birthday?

with bn as ( select Cast(concat(birthyear,'-', birthmonth,'-', birthday) as DATE ) as Birthday, 
namegiven  from players)

select birthday, group_concat(namegiven separator',') as players from bn
where year(birthday) between 1980  and 1990
group by birthday
order by birthday;

-- 3. Create a summary table that shows for each team, what percent of players bat right, left and both
select * from players;

select teamid,
 round(sum(case when p.bats = 'R' then 1 else 0 end) / count(s.playerid)*100, 1) as Right_hand,
 round(sum(case when p.bats = 'L' then 1 else 0 end) / count(s.playerid)*100, 1) as Left_hand,
 round(sum(case when p.bats = 'B' then 1 else 0 end) / count(s.playerid)*100, 1) as bats_both
 from salaries s
 left join players p on 
 s.playerid = p.playerid
 group by s.teamid;

-- 4. How have average height and weight at debut game changed over the years, and what's the decade-over-decade difference?

select * from players;

with hw as (select round(year(debut), -1) as decade, avg(height) as avg_height, avg(weight) as avg_weight from players
group by decade
order by decade)
 select decade,
  avg_height - lag(avg_height) over(order by decade) as height_diff,
  avg_weight - lag(avg_weight) over(order by decade) as weigth_diff
  from hw
   where decade is not null;

